#!/usr/bin/perl

use strict;
use FindBin qw($Bin);
use lib $Bin;
use Bio::SeqIO;

my $fafile1 = $ARGV[0];
my $fafile2 = $ARGV[1];
my $wordlen = $ARGV[2];
my $markovorder = $ARGV[3];

my $tmpdir = "$Bin/tmp";
mkdir($tmpdir);

if ($#ARGV < 3) {
    print "usage: wrap_d2z.pl <fasta file 1> <fasta file 2> <word length> [<markov order>]\n";
    die;
}

if ($wordlen < 2 || $wordlen > 8) {
    die "Error: word length should be an integer between 2 and 8\n";
}

if ($markovorder < 0 || $markovorder > 3 || $markovorder >= $wordlen) {
    die "Error: Markov order should be an integer between 0 and 3, and less than word length\n";
}


Process("$Bin/kworddistr.pl $fafile1 $wordlen $tmpdir/counts.1.txt");
Process("$Bin/kworddistr.pl $fafile2 $wordlen $tmpdir/counts.2.txt");

my $bkgwordlen = $markovorder+1;
Process("$Bin/kworddistr.pl $fafile1 $bkgwordlen $tmpdir/counts.bkg.1.txt");
Process("$Bin/kworddistr.pl $fafile2 $bkgwordlen $tmpdir/counts.bkg.2.txt");

my $maxnumgenes1 = 0;
my $fo1 = Bio::SeqIO->new(-file=>$fafile1, 
			 -format=>'Fasta');
while (my $f1 = $fo1->next_seq()) {
    $maxnumgenes1++;
}
my $maxnumgenes2 = 0;
my $fo2 = Bio::SeqIO->new(-file=>$fafile2, 
			 -format=>'Fasta');
while (my $f2 = $fo2->next_seq()) {
    $maxnumgenes2++;
}

if ($maxnumgenes1 < 1 || $maxnumgenes2 < 1) {
    die "Error: could not read at least one fasta sequence in each input file\n";
}

my $maxnumgenes = $maxnumgenes1;
if ($maxnumgenes2>$maxnumgenes) {
    $maxnumgenes = $maxnumgenes2;
}

if ($markovorder > 0) {
    Process("$Bin/markov/bin/d2zmm $tmpdir/counts.1.txt $tmpdir/counts.2.txt $tmpdir/counts.bkg.1.txt $tmpdir/counts.bkg.2.txt $wordlen $bkgwordlen $maxnumgenes");
}
else {
    Process("$Bin/iid/bin/d2ziid $tmpdir/counts.1.txt $tmpdir/counts.2.txt $tmpdir/counts.bkg.1.txt $tmpdir/counts.bkg.2.txt $wordlen $maxnumgenes");
}

sub Process {
    my $c = shift;
    warn "$c\n";
    system $c;
}
